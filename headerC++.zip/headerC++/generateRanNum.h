
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int getRandomNumber();

