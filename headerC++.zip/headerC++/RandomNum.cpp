#include <iostream>
#include "generateRanNum.h"
using namespace std;

void tryRandNum();
int main() {
	tryRandNum();
//	int number = getRandomNumber();
//	cout << tryRandNum() << endl;
	return 0;
}
void tryRandNum() {
	int howMany; 		// how many times user want to guess the number
	int countVal = 0; 	// increment countVal by one if user correctlly guess the number
	int guessedVal;		// user guessed value
	cout << "How many times do you want to guess the number: ";
	cin >> howMany;
	for (int i = 0; i < howMany; i++) {
		cout << "Guess the number from 1 to 10: ";
		cin >> guessedVal;
		cout << "The random number is ";
		cout << getRandomNumber() << endl;
		if(guessedVal == getRandomNumber()) {
			countVal++;
		}
	
	}
	cout << "you correctly guess " << countVal << " times from " << howMany << " guess" << endl;
	
}
int getRandomNumber() {
	srand(time(0));
	return rand() % 10 + 1;
}
